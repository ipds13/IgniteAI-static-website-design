import"./BxZkyR8a.js";const r=""+new URL("igniteAI-06.6ZjVIqSx.png",import.meta.url).href;export{r as _};
